from django.db import models
from django.urls import reverse

class User(models.Model):
    username = models.CharField(max_length=100)
    password = models.CharField(max_length=100)
    email = models.CharField(max_length=100)
    group = models.CharField(max_length=100)

    def __str__(self):
        return self.username


class Question(models.Model):
    question_statement = models.CharField(max_length=5500)
    question_mark = models.CharField(max_length=20)
    question_type = models.CharField(max_length=20, choices={('easy','EASY')
        ,('medium','MEDIUM')
        ,('hard','HARD')})
    question_counter = models.IntegerField(default=0)
    blooms = models.CharField(max_length=100, default="understanding")
    # # choices (actual value, human readable)
    # question_category = models.CharField(max_length=20, choices={
    #     ('IAT1','IAT1'),
    #     ('IAT2','IAT2'),
    #     ('ESE', 'ESE')})
    # question_department = models.CharField(max_length=20, choices={
    #     ('IT', 'IT'),
    #     ('COMPS', 'COMPS'),
    #     ('EXTC', 'EXTC'),
    #     ('MECH', 'MECH')
    # })
    # question_year = models.CharField(max_length=20, choices={
    #     ('SE', 'SE'),
    #     ('TE', 'TE'),
    #     ('BE', 'BE')
    # })
    # question_subject = models.CharField()   # depending on question_year

    def __str__(self):
        return '%s - %s  - %s' %(self.question_statement,self.question_type, self.question_mark)

    def get_absolute_url(self):
        return reverse('quesgen-viewquestion')