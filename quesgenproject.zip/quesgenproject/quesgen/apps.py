from django.apps import AppConfig


class QuesgenConfig(AppConfig):
    name = 'quesgen'
