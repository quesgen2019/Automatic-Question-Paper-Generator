from django.contrib import admin
from .models import Question, User

class QuestionA(admin.ModelAdmin):
    list_display = ('question_statement','question_mark','question_type', 'question_counter', 'blooms')

# Register your models here.
admin.site.register(Question, QuestionA)
admin.site.register(User)