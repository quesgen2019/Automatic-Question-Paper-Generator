from django.contrib.auth.models import User, Group
from django import forms
from django.contrib.auth import (
    authenticate,
    get_user_model
)
from .models import Question

User = get_user_model()

# Creating User Registration Form
class UserForm(forms.ModelForm):
    type = forms.ModelChoiceField(queryset=Group.objects.all(), required=True)
    username = forms.CharField(label="Username", widget=forms.TextInput)
    password = forms.CharField(label="Password", widget=forms.PasswordInput, min_length=8)
    email = forms.CharField(label="Email", widget=forms.EmailInput)
    first_name = forms.CharField(label="First Name", widget=forms.TextInput)
    last_name = forms.CharField(label="Last Name", widget=forms.TextInput)

    class Meta:
        model = User
        fields = ('username', 'first_name', 'last_name', 'email', 'type','password',)

# Creating User Login Form
class UserLoginForm(forms.Form):
	username = forms.CharField()
	password = forms.CharField(widget=forms.PasswordInput)

	def clean(self, *args, **kwargs):
		username = self.cleaned_data.get("username")
		password = self.cleaned_data.get("password")

		if username and password:
			user = authenticate(username=username, password= password)
			if not user:
				raise forms.ValidationError("User does not exist")
			if not user.check_password(password):
				raise forms.ValidationError("Invalid credentials")
			if not user.is_active:
				raise forms.ValidationError("User is not active")
		return super(UserLoginForm, self).clean(*args, **kwargs)

class GeneratePaperForm(forms.ModelForm):
	class Meta:
		model = Question
		fields = ('question_type', )