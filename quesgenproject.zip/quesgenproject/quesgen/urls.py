from django.urls import path, include
from .views import QuestionListView, QuestionCreateView,QuestionDetailView, QuestionUpdateView, GenerateQuestionPaper
from . import views

urlpatterns = [
    path('', views.home, name='quesgen-home'),
    path('register/', views.UserForm.as_view(), name='quesgen-register'),
    path('login/', views.login_view, name='quesgen-login'),
    path('logout/', views.logout_view, name='quesgen-logout'),
    path('teacheractivity/', views.teacher_activity, name='quesgen-teacheractivity'),
    path('question/add/', QuestionCreateView.as_view(), name='quesgen-addquestion'),
    path('question/updatequestion/<int:pk>', QuestionUpdateView.as_view(), name='quesgen-updatequestion'),
    path('question/view', QuestionListView.as_view(), name='quesgen-viewquestion'),
    path('question/<int:pk>', QuestionDetailView.as_view(), name='quesgen-detailquestion'),
    path('question/pdf', views.get_pdf, name='quesgen-getpdf'),
    path('question/papergenerate', GenerateQuestionPaper.as_view(), name='quesgen-generatequestionpaper'),
    path('question/viewpapergenerated', views.view_generated_paper, name='quesgen-viewgeneratedquestionpaper'),

]