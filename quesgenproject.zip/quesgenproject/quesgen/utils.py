from io import BytesIO
from django.http import HttpResponse
from django.template.loader import get_template
import os
from xhtml2pdf import pisa
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

def render_to_pdf(template_src, context_dict={}):
    template = get_template(template_src)
    html  = template.render(context_dict)
    result = BytesIO()


    file = open('C:\\Users\\Darina Gomes\\Desktop\\Generated\\Questionpaper_IAT.pdf', "w+b")
    pisaStatus = pisa.CreatePDF(html.encode('utf-8'), dest=file,
                                encoding='utf-8')

    file.seek(0)
    pdfd = file.read()
    file.close()

    pdf = pisa.pisaDocument(BytesIO(html.encode("ISO-8859-1")), result)
    c = os.listdir("C:\\Users\\Darina Gomes\\Desktop\\Generated")
    for file in c:
        print(file)


    if not pdf.err:
        # fromaddr = "quesgen2019@gmail.com"
        # toaddr = "darinagomes@gmail.com"
        #
        # msg = MIMEMultipart()
        #
        # msg['From'] = fromaddr
        # msg['To'] = toaddr
        # msg['Subject'] = "Generated test paper"
        # body = "Here is your generated test sir"
        # msg.attach(MIMEText(body, 'plain'))
        #
        # filename = "Questionpaper_IAT.pdf"
        #
        # attachment = open("C:\\Users\\Darina Gomes\\Desktop\\Generated\\Questionpaper_IAT.pdf", "rb")
        #
        # print("Attachment", attachment)
        #
        # part = MIMEBase('application', 'octet-stream')
        # part.set_payload((attachment).read())
        # encoders.encode_base64(part)
        # part.add_header('Content-Disposition', "attachment; filename= %s" % filename)
        #
        # msg.attach(part)
        # conn = smtplib.SMTP('smtp.gmail.com', 587)
        # conn.ehlo()
        # conn.starttls()
        # conn.login('quesgen2019@gmail.com', 'D@rinaGomez')
        # text = msg.as_string()
        # conn.sendmail(fromaddr, toaddr, text)
        # conn.quit()

        return HttpResponse(result.getvalue(), content_type='application/pdf')
    return None