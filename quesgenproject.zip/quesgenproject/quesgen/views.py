from django.shortcuts import render, redirect
from . import forms
from django.http import HttpResponse
from django.views import View
from django.views.generic import ListView, DetailView, CreateView, UpdateView, FormView
from django.contrib.auth.models import Group, User
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.contrib.auth.decorators import (
    login_required,
    user_passes_test
)
from .models import Question
from django.views.decorators.csrf import csrf_protect
from django.contrib.auth import (
    authenticate,
    get_user_model,
    login,
    logout
)
from pathlib import Path
import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from random import randint
from django.template.loader import get_template
from .utils import render_to_pdf
import nltk

nltk.download('punkt')
nltk.download('averaged_perceptron_tagger')

# List of verbs of individual category
Creating = ["generate", "combine", "construct", "formulate", "propose"]
Evaluating = ["justify", "conclude", "evaluate", "determine", "verify"]
Analyzing = ["distinguish", "compare", "classify", "categorize"]
Applying = ["change", "demonstrate", "modify", "solve", "show"]
Understanding = ["explain", "convert", "estimate", "derive", "review", "relate"]
Remembering = ["name", "list", "define", "label", "sketch", "identify", "write"]

# List of all categories
bloom = [Creating, Evaluating, Analyzing, Applying, Understanding, Remembering]

# Number and Category Dictionary
level = {'0': 'Creating',
         '1': 'Evaluating',
         '2': 'Analyzing',
         '3': 'Applying',
         '4': 'Understanding',
         '5': 'Remembering'
         }


def find_category(verb):
    count = 0
    for b in bloom:
        if verb.lower() in b:
            return level[str(count)]
        count = count + 1



# Create your views here.
# Checking whether user is in hod group
q2 = []
q5_a = []
q5_b = []

def not_in_hods_group(user):
    if user:
        return user.groups.filter(name="hod").count() == 0
    return False

@property
def in_hods_group(user):
    if user:
        return False
    return user.groups.filter(name="hod").count() == 0


# Checking whether user is in teacher group
def not_in_teachers_group(user):
    if user:
        return user.groups.filter(name="teacher").count() == 0
    return False

@property
def in_teachers_group(user):
    if not user:
        return False
    return user.groups.filter(name="teacher").count() == 0


def home(request):
    context = {
        'question': Question.objects.all()
    }
    return render(request, 'quesgen/home.html', {'title': 'Home'})

global verb
global category


class QuestionCreateView(LoginRequiredMixin, UserPassesTestMixin, CreateView):
    model = Question
    fields = ['question_statement',
              'question_mark',
              'question_type']
    template_name = 'quesgen/add_question.html'

    global category
    global verb


    def post(self, request, *args, **kwargs):
        question_statement = request.POST['question_statement']
        question_mark = request.POST['question_mark']
        question_type = request.POST['question_type']

        # print(question_statement)
        tokens = nltk.word_tokenize(question_statement)
        # print(tokens)
        tagged = nltk.pos_tag(tokens)
        # print(tagged)
        category=""

        for t in tagged:
            category = find_category(t[0])
            if category:
                break
        else:
            category = "Understanding"

        Question.objects.create(question_statement=question_statement,
                                    question_type=question_type,
                                    question_mark=question_mark,
                                    blooms=category)
        return render(request, 'quesgen/home.html')



    def test_func(self):
        if self.request.user:
            return self.request.user.groups.filter(name="teacher").count() == 0
        return True

# verb = ""
# category = ""

class QuestionListView(LoginRequiredMixin, ListView):
    model = Question
    template_name = 'quesgen/view_question.html'
    context_object_name = 'question'

class QuestionDetailView(LoginRequiredMixin, DetailView):
    model = Question
    template_name = 'quesgen/detail_question.html'
    context_object_name = 'question'

# @user_passes_test(not_in_hods_group, login_url="quesgen-login")
class QuestionUpdateView(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
    model = Question
    fields = ['question_statement',
              'question_mark',
              'question_type']
    template_name = 'quesgen/update_question.html'

    def test_func(self):
        if self.request.user:
            return self.request.user.groups.filter(name="hod").count() != 0
        return True

    # def form_valid(self, form):
    #     form.instance.id = self.form.id
    #     return super().form_valid(form)



@login_required
@user_passes_test(not_in_teachers_group, login_url="quesgen-login")
def teacher_activity(request):
    return render(request, 'quesgen/teacher_activity.html')


@csrf_protect
def login_view(request):
    next = request.GET.get('next')
    print(next)
    form = forms.UserLoginForm(request.POST or None)
    if form.is_valid():
        username = form.cleaned_data.get("username")
        password = form.cleaned_data.get("password")
        user = authenticate(username=username, password=password)
        login(request, user)
        if next:
            return redirect(next)
        return redirect('quesgen-home')
    # return redirect('quesgen-home')

    context = {
        'form': form,
    }
    return render(request, "quesgen/login.html", context)

def logout_view(request):
    logout(request)
    return redirect('quesgen-home')

def add_question(request):
    return render(request, 'quesgen/add_question.html')

def view_generated_paper(request):
    return render(request, 'quesgen/viewgeneratedpaper.html')

class GenerateQuestionPaper(View):
    form_class = forms.GeneratePaperForm
    template_name = 'quesgen/generate_question_paper.html'

    def get(self, request):
        form = self.form_class(None)
        return render(request, self.template_name, {'form': form})

    def post(self, request):
        form = self.form_class(request.POST)

        if form.is_valid():
            data = form.save(commit=False)
            question_type = form.cleaned_data['question_type']

            if question_type == "easy":

                rs2 = Question.objects.filter(question_mark=2, question_type='easy', blooms='Remembering')
                for q in rs2:
                    if len(q2) != 6:
                        q2.append(q.question_statement)
                    else:
                        break

                        # print(rs2)

                rs5_a = Question.objects.filter(question_mark=5, question_type='easy', blooms='Remembering')
                for q in rs5_a:
                    if len(q5_a) != 2:
                        q5_a.append(q.question_statement)
                    else:
                        break

                # # Generate random questions
                # c = Question.objects.filter(question_mark=5, question_type='easy').count()
                # ri = randint(0, c-1)
                # randd = Question.objects.filter(question_mark=5, question_type='easy').all()[ri]
                # rii = randint(0, c-1)
                # randd2 = Question.objects.filter(question_mark=5, question_type='easy').all()[rii]
                # print(randd)
                # print(randd2)

                rs5_b = Question.objects.filter(question_mark=5, question_type='medium', blooms='Understanding')
                for q in rs5_b:
                    if not q.question_statement in q5_a:
                        if len(q5_b) != 2:
                            q5_b.append(q.question_statement)
                        else:
                            break

            elif question_type == "medium":

                rs2 = Question.objects.filter(question_mark=2, question_type='easy', blooms='Remembering')
                for q in rs2:
                    if len(q2) != 6:
                        q2.append(q.question_statement)
                    else:
                        break

                        print(rs2)

                rs5_a = Question.objects.filter(question_mark=5, question_type='medium', blooms='Applying')
                for q in rs5_a:
                    if len(q5_a) != 2:
                        q5_a.append(q.question_statement)
                    else:
                        break

                # # Generate random questions
                # c = Question.objects.filter(question_mark=5, question_type='easy').count()
                # ri = randint(0, c-1)
                # randd = Question.objects.filter(question_mark=5, question_type='easy').all()[ri]
                # rii = randint(0, c-1)
                # randd2 = Question.objects.filter(question_mark=5, question_type='easy').all()[rii]
                # print(randd)
                # print(randd2)

                rs5_b = Question.objects.filter(question_mark=5, question_type='medium', blooms='Understanding')
                for q in rs5_b:
                    if not q.question_statement in q5_a:
                        if len(q5_b) != 2:
                            q5_b.append(q.question_statement)
                        else:
                            break
            else:

                rs2 = Question.objects.filter(question_mark=2, question_type='easy', blooms='Applying')
                for q in rs2:
                    if len(q2) != 6:
                        q2.append(q.question_statement)
                    else:
                        break

                        print(rs2)

                rs5_a = Question.objects.filter(question_mark=5, question_type='medium', blooms='Evaluating')
                for q in rs5_a:
                    if len(q5_a) != 2:
                        q5_a.append(q.question_statement)
                    else:
                        break

                # # Generate random questions
                # c = Question.objects.filter(question_mark=5, question_type='easy').count()
                # ri = randint(0, c-1)
                # randd = Question.objects.filter(question_mark=5, question_type='easy').all()[ri]
                # rii = randint(0, c-1)
                # randd2 = Question.objects.filter(question_mark=5, question_type='easy').all()[rii]
                # print(randd)
                # print(randd2)

                rs5_b = Question.objects.filter(question_mark=5, question_type='hard', blooms='Analyzing')
                for q in rs5_b:
                    if not q.question_statement in q5_a:
                        if len(q5_b) != 2:
                            q5_b.append(q.question_statement)
                        else:
                            break


            context = {
                'q2': q2,
                'q5_a': q5_a,
                'q5_b': q5_b
            }

            return redirect('quesgen-getpdf')

        return render(request, self.template_name, {'form': form})


def send_mail():
    fromaddr = "quesgen2019@gmail.com"
    toaddr = "darinagomes@gmail.com"

    msg = MIMEMultipart()

    msg['From'] = fromaddr
    msg['To'] = toaddr
    msg['Subject'] = "Generated test paper"
    body = "Question Paper"
    msg.attach(MIMEText(body, 'plain'))

    filename = "Questionpaper_IAT.pdf"
    attachment = open("C:\\Users\\Darina Gomes\\Desktop\\Generated\\Questionpaper_IAT.pdf", "rb")

    print("Attachment",attachment)

    part = MIMEBase('application', 'octet-stream')
    part.set_payload((attachment).read())
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', "attachment; filename= %s" % filename)

    msg.attach(part)
    conn = smtplib.SMTP('smtp.gmail.com', 587)
    conn.ehlo()
    conn.starttls()
    conn.login('quesgen2019@gmail.com', 'D@rinaGomez')
    text = msg.as_string()
    conn.sendmail(fromaddr, toaddr, text)
    conn.quit()

def get_pdf(request):
    context = {
        'questiona': q2,
        'questionb': q5_a,
        'questionc': q5_b,
    }

    template = get_template('quesgen/pdf_question.html')
    html = template.render(context)
    pdf = render_to_pdf('quesgen/pdf_question.html', context)
    if pdf:
        q2.clear()
        q5_a.clear()
        q5_b.clear()
        response = HttpResponse(pdf, content_type='application/pdf')
        filename = "Questionpaper_%s.pdf" % ("IAT")
        content = "inline; filename=%s" % (filename)
        download = request.GET.get("download")
        if download:
            content = "attachment; filename='%s'" % (filename)
        response['Content-Disposition'] = content


        if response:
            send_mail()
        return response


    return HttpResponse("Not Found")





class UserForm(View):
    form_class = forms.UserForm
    template_name = 'quesgen/register.html'

    # Displaying blank form
    def get(self, request):
        form = self.form_class(None)
        return render(request, self.template_name, {'form': form})

    # Process form data
    def post(self, request):
        form = self.form_class(request.POST)

        if form.is_valid():
            user = form.save(commit=False)
            username = form.cleaned_data['username']
            first_name = form.cleaned_data['first_name']
            last_name = form.cleaned_data['last_name']
            email = form.cleaned_data['email']
            password = form.cleaned_data['password']
            user.set_password(password)

            group = form.cleaned_data['type']
            user.save()
            g = Group.objects.get(name=group)
            g.user_set.add(user)
            # print(group)
            # group.user_set.add(user)
            return render(request, 'quesgen/login.html')

        return render(request, self.template_name, {'form': form})

